package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;


import com.entity.student;
import com.entity.studentmarks;
import com.service.StudentService;
import com.entity.studentmarks;

@RestController
@RequestMapping(value = "Student")
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	@GetMapping(value = "findStudentById/{sid}")
	public student findStudentById(@PathVariable("sid") int sid) {
		return studentService.findStudentById(sid);
	}
	
	@GetMapping(value = "showMarksDetails/{sid}")
	public studentmarks showMarksDetails(@PathVariable("sid")int sid){
		return studentService.showMarksDetails(sid);
	} 
	
	@PutMapping(value = "updateMarksDetails" ,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateMarksDetails(@RequestBody studentmarks marks ) {
		return studentService.updateMarksDetails(marks);
	}
}
