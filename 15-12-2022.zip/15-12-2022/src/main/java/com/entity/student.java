package com.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sid;
	private String sname;
	private int age;
	private String sclass;
	private String section;
	@OneToOne(cascade = CascadeType.ALL)					
	@JoinColumn(name = "sid",referencedColumnName = "mid")
	private studentmarks marks;

	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSclass() {
		return sclass;
	}
	public void setSclass(String sclass) {
		this.sclass = sclass;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public studentmarks getMarks() {
		return marks;
	}
	public void setMarks(studentmarks marks) {
		this.marks = marks;
	}
	public student(int sid, String sname, int age, String sclass, String section, studentmarks marks) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.age = age;
		this.sclass = sclass;
		this.section = section;
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "student [sid=" + sid + ", sname=" + sname + ", age=" + age + ", sclass=" + sclass + ", section="
				+ section + ", marks=" + marks + "]";
	}
	public student() {
		super();
	}	
}
